// lib/services/destination_service.dart
import 'package:supabase_flutter/supabase_flutter.dart';
import 'supabase_client.dart';

class DestinationService {
  final SupabaseClient _client = SupabaseClientService.client;

  /// Fetch all destinations (optionally filter by open status and minimum locker count)
  Future<List<Map<String, dynamic>>> getDestinations({bool onlyOpen = true, int minLockers = 0}) async {
    final query = _client.from('destinations').select('*');
    if (onlyOpen) {
      query.eq('status', 'OPEN');
    }
    if (minLockers > 0) {
      query.gt('locker_count', minLockers - 1);
    }
    final res = await query.order('created_at', ascending: true).execute();
    if (res.error != null) throw res.error!;
    return (res.data as List).cast<Map<String, dynamic>>();
  }

  /// Get aggregated ratings view
  Future<List<Map<String, dynamic>>> getDestinationsRatingsAvg({int limit = 50}) async {
    final res = await _client.from('destinations_ratings_avg').select('*').order('avg_rating', ascending: false).limit(limit).execute();
    if (res.error != null) throw res.error!;
    return (res.data as List).cast<Map<String, dynamic>>();
  }

  /// Insert or update a rating (upsert)
  Future<void> upsertRating({required String destinationId, required int rating, String? comment}) async {
    final userId = SupabaseClientService.userId;
    if (userId == null) throw Exception('Not authenticated');
    final payload = {
      'user_id': userId,
      'destination_id': destinationId,
      'rating': rating,
      'comment': comment
    };
    final res = await _client.from('ratings').upsert(payload, returning: ReturningOption.minimal).execute();
    if (res.error != null) throw res.error!;
  }

  /// Create a ride/reservation
  Future<void> createRide({required String destinationId, required String pickupAddress, String? destinationAddress}) async {
    final userId = SupabaseClientService.userId;
    if (userId == null) throw Exception('Not authenticated');
    final payload = {
      'user_id': userId,
      'destination_id': destinationId,
      'pickup_address': pickupAddress,
      'destination_address': destinationAddress,
      'status': 'PENDING'
    };
    final res = await _client.from('rides').insert([payload]).execute();
    if (res.error != null) throw res.error!;
  }
}
