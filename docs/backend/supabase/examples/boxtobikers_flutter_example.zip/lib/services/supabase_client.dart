// lib/services/supabase_client.dart
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

/// SupabaseClientService
/// Initialize Supabase once in your app and use SupabaseClientService.client to access the client.
class SupabaseClientService {
  static late final SupabaseClient client;

  /// Call this in main() after loading environment variables.
  static Future<void> init() async {
    final url = dotenv.env['SUPABASE_URL'];
    final anonKey = dotenv.env['SUPABASE_ANON_KEY'];
    if (url == null || anonKey == null) {
      throw Exception('SUPABASE_URL and SUPABASE_ANON_KEY must be set in .env');
    }
    await Supabase.initialize(url: url, anonKey: anonKey, authCallbackUrlHostname: 'login-callback');
    client = Supabase.instance.client;
  }

  /// Convenience shortcut to current user id
  static String? get userId => client.auth.currentUser?.id;

  /// Sign in with email & password
  static Future<void> signIn(String email, String password) async {
    final res = await client.auth.signInWithPassword(email: email, password: password);
    if (res.session == null) {
      throw Exception('Sign in failed');
    }
  }

  /// Sign up
  static Future<void> signUp(String email, String password) async {
    await client.auth.signUp(email: email, password: password);
  }

  /// Sign out
  static Future<void> signOut() async {
    await client.auth.signOut();
  }
}
