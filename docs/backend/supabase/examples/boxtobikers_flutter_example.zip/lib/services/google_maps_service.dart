// lib/services/google_maps_service.dart
import 'package:dio/dio.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class GoogleMapsService {
  final Dio _dio = Dio(BaseOptions(baseUrl: 'https://maps.googleapis.com/maps/api'));

  String get _apiKey => dotenv.env['GOOGLE_MAPS_API_KEY'] ?? '';

  /// Place search (autocomplete)
  Future<Map<String, dynamic>> placeAutocomplete(String input, {String? sessionToken}) async {
    final res = await _dio.get('/place/autocomplete/json', queryParameters: {
      'input': input,
      'key': _apiKey,
      if (sessionToken != null) 'sessiontoken': sessionToken,
    });
    return res.data as Map<String, dynamic>;
  }

  /// Place details by place_id
  Future<Map<String, dynamic>> placeDetails(String placeId) async {
    final res = await _dio.get('/place/details/json', queryParameters: {
      'place_id': placeId,
      'key': _apiKey,
      'fields': 'place_id,name,formatted_address,geometry,opening_hours,rating,photos',
    });
    return res.data as Map<String, dynamic>;
  }

  /// Reverse geocode lat/lng to address
  Future<Map<String, dynamic>> reverseGeocode(double lat, double lng) async {
    final res = await _dio.get('/geocode/json', queryParameters: {
      'latlng': '\$lat,\$lng'.replaceAll(r'$', ''),
      'key': _apiKey,
    });
    return res.data as Map<String, dynamic>;
  }
}
