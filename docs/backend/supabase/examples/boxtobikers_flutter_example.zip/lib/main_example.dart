// lib/main_example.dart
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'services/supabase_client.dart';
import 'services/destination_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env");
  await SupabaseClientService.init();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Boxtobikers Demo',
      home: const HomeView(),
    );
  }
}

class HomeView extends StatefulWidget {
  const HomeView({super.key});
  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  final DestinationService _dstService = DestinationService();
  List<Map<String, dynamic>> _destinations = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final list = await _dstService.getDestinations();
      setState(() => _destinations = list);
    } catch (e) {
      debugPrint('Error loading destinations: \$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Boxtobikers')),
      body: ListView.builder(
        itemCount: _destinations.length,
        itemBuilder: (context, i) {
          final d = _destinations[i];
          return ListTile(
            title: Text(d['name'] ?? 'Unnamed'),
            subtitle: Text(d['address'] ?? ''),
            trailing: Text('Lockers: \${d['locker_count'] ?? 0}'),
          );
        },
      ),
    );
  }
}
