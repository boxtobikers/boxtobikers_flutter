# Boxtobikers Flutter Example - Services

This small example includes ready-to-use Dart service files to interact with your **Boxtobikers** Supabase backend and Google Maps.

Files included:
- `lib/services/supabase_client.dart` — Supabase initialization and simple auth helpers
- `lib/services/destination_service.dart` — CRUD operations for destinations, rides and ratings
- `lib/services/google_maps_service.dart` — Example usage of **Dio** to call Google Maps Places API
- `.env.example` — Example environment variables

## Usage

1. Copy `.env.example` to `.env` and fill in values:
```
SUPABASE_URL=https://your-project-ref.supabase.co
SUPABASE_ANON_KEY=your-anon-key
GOOGLE_MAPS_API_KEY=your-google-maps-api-key
```

2. Add packages to `pubspec.yaml`:
```yaml
dependencies:
  flutter:
    sdk: flutter
  supabase_flutter: ^1.0.0
  dio: ^5.0.0
  flutter_dotenv: ^5.0.2
```

3. Example usage in your `main.dart`:
```dart
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'services/supabase_client.dart';
import 'services/destination_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env");
  await SupabaseClientService.init();
  runApp(const MyApp());
}
```

4. Use `DestinationService` to fetch destinations or add ratings.

---

This package is intended as a starting point. You should adapt error handling, state management (Riverpod/Provider/Bloc), and UI integration to your app.
